local Tunnel = module('_core', 'lib/Tunnel')
local Proxy = module('_core', 'lib/Proxy')

API = Proxy.getInterface('API')
cAPI = Tunnel.getInterface('API')


RegisterNetEvent('ROUBO:sheriffs_call')
AddEventHandler('ROUBO:sheriffs_call', function(amount)
          
end)