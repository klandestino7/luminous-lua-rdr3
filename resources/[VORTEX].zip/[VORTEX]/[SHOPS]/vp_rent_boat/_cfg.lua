Config = {}

Config.NoMoney = 'Não tem dinheiro suficiente $'
Config.Shoptext = 'Aperte (E) para alugar um bote'
Config.LevelMissing = 'Você não tem experiência suficiente' 
Config.Coords = {
	vector3(-686.16, -1243.67, 43.1),
	vector3(2883.17, -1354.51, 42.61),
	vector3(3030.43, 553.86, 44.71),
}