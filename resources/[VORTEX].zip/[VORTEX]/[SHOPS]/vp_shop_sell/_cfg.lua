Config = {}

Config.ShopDatas = {
	{
		name = "Geral",
		{
			{"tobacco", 1, 1},
			{"corn", 1, 1},
			-- {"sugarcane", 1, 1}
		}
	}
}

Config.ShopLocations = {
	["Geral"] = {
		{-883.373,-1421.761,44.413}
	}
}
