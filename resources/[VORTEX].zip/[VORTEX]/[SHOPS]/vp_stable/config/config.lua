Config = {}

Config.Stables = {
	Valentine = {	   
		Pos = {x=-367.73, y=787.72, z=116.26},
		Name = 'Estábulo',
        Heading = -30.65,
		SpawnPoint = {
			Pos = {x=-372.43, y=791.79, z=116.13},
			CamPos = {x=1, y=-3, z=0},
			Heading = 182.3
        }
	},
	BlackWater = {
		Pos = {x=-873.167, y=-1366.040, z=43.531},
		Name = 'Estábulo',
        Heading = 266.84,
		SpawnPoint = {
			Pos = {x=-864.373, y=-1361.485, z=43.702},
			CamPos = {x=-1.2, y=-3, z=0},
			Heading = 181.91
        }
    },
	Saint_Denis = {
		Pos = {x=2503.153, y=-1442.725, z=46.312},
		Name = 'Estábulo',
        Heading = 169.45,
		SpawnPoint = {
			Pos = {x=2508.822, y=-1449.949, z=46.402},
			CamPos = {x=-3, y=3, z=0},
			Heading = 93.13
        }
    },
}



