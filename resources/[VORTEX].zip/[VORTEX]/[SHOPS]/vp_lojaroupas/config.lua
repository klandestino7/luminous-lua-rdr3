Config = {}

Config.NoMoney = 'Não tem dinheiro suficiente $'
Config.Shoptext = 'Aperte (ALT) para comprar roupas'
Config.Coords = {
	vector3(-762.85, -1291.97, 43.84), -- Blackwater
	vector3(2549.83, -1160.05, 53.73), -- SAINT DENIS
	vector3(-322.25, 803.97, 116.95), -- VALENTINES
}
