Config = {}

Config.Tents = {
    {
        id = 1,
        tentModel = 615627222,
        tentText = "Tenda",
        tentLabel = "Armando Tenda...",
        tentSpawnTime = 15000,
        itemId = 82
    },
    {
        id = 2,
        tentModel = 1231676579,
        tentText = "Tenda",
        tentLabel = "Armando Tenda...",
        tentSpawnTime = 25000,
        itemId = 83
    },
    {
        id = 3,
        tentModel = -838945132,
        tentText = "Tenda",
        tentLabel = "Armando Tenda...",
        tentSpawnTime = 30000,
        itemId = 84
    },
    {
        id = 4,
        tentModel = -1179266405,
        tentText = "Fogueira",
        tentLabel = "Armando Fogueira...",
        tentSpawnTime = 10000,
        itemId = 85
    }
}