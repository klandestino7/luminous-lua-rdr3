ConfigStaticChests = {
    -- {
    --     x,
    --     y,
    --     z,
    --     h,
    --     type, -- GLOBAL[0] | PUBLIC[1] | PRIVATE[2]
    --     capacity,
    --     group,
    -- },
    {
        'static:house:2',
        1367.807,
        -878.481,
        70.121,
        90.00,
        0,
        20,
        -- "house:2"
    }
}
