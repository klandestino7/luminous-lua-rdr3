RequestImap(1879779330)-- sign outside tent version 1
RequestImap(1104143966)-- sign outside tent version 2
RequestImap(1027093524) --sign outside tent version 3
RequestImap(-1617847332) -- sign outside tent version 4
RequestImap(-763477089)  -- partial door flap open
RequestImap(317070801) -- full closed flap
RequestImap(619024057) -- Saint Denis Doctors office full interior with doors

------------------------------------- Green House Valentine
RequestImap(903666582)  
------------------------------------- #### END Green House ####

------------------------------------- Railroad Stuff
--RequestImap(-794503195) -- Broken Bridge and Pieces Pieces  -- 520 1754 187

------------------------------------- Central Union Train Mission
RequestImap(2077623691) -- Track Bed - Full Legnth
RequestImap(-555736180) -- Crossing 1818
RequestImap(-693812694) --Section 1 1875
RequestImap(-1386614896) --Section 2 Track at 2070
RequestImap(2080640229) --Section 3 2156
RequestImap(-805522215) --Section 4 2177
RequestImap(499044444) --Section 5
RequestImap(-196117122) --Section 6 2184
RequestImap(-1022518533) --Section 7 2201
RequestImap(691955519) --Section 8 with bridge 2203
RequestImap(-142900294) --Section 9 2229.82

RequestImap(-84516711)  --Run Down Closed Station
RequestImap(-657241692)  --Oil Pipe
RequestImap(-1112373128)  --Oil Tower
------------------------------------- #### Heartland Oil Station ####
------------------------------------- Hole Near Rhodes - Woman's Rights Mission Start
RequestImap(1277540472)  -- 1433 -1591 69
------------------------------------- #### END OF WOMAN'S RIGHTS ####
------------------------------------- Story Camp Near Rhodes
-- GRASS and GROUND
RequestImap(-1496619689) -- Green Ground 670 -1236 44
RequestImap(-61896664) -- Worn Brown Ground 670 -1236 44
RequestImap(-648893593) -- Version 1 of Grass and Ferns
RequestImap(1534006738) -- Version 2 of Grass and Ferns
RequestImap(-376056363) -- Version 3 of Grass and Ferns
RequestImap(519091847)  -- Version 4 of Grass and Ferns
RequestImap(-1225606266) -- Adds bush to 692 -1263 44
RequestImap(-1874720370) -- Lots of ferns, weeds and tall grass
RequestImap(-1936937394) -- Grass, Flowers and weeds]]

-- German Guys Wagon
RequestImap(1679038623) -- Wagon v2  657 -1231 44
RequestImap(-462274808) -- Small Box in wgaon
RequestImap(-1284301817) -- Antlers on German Wagon
RequestImap(1169958167) -- Red Table Cloth German Wagon

--Arthurs Wagon
RequestImap(2072112547) --  Wagon v1 with Canopy
RequestImap(1601820048) -- Hide Rug 
RequestImap(2025485344) -- Table Top 
RequestImap(901520480) -- Table 
RequestImap(-1999465365) -- Right Skull  Wagon
RequestImap(853723410) -- Left Alligator Skull  Wagon
RequestImap(-1774140220) --  Chest v1
RequestImap(102652153) --  Shaving Kit
RequestImap(-1739164071) -- Book on Small Table 
RequestImap(-1331617405) --  Book
RequestImap(-959814975) -- Box by Book v1
RequestImap(1096093290) -- Quiver on Ground
RequestImap(976082270) -- Tools, painting, guns
RequestImap(153759048) -- Chair
RequestImap(-1147256587) -- Map
RequestImap(1676971154) -- Photo

-- Pearsons Wagon
RequestImap(764763647) -- Provisions Wagon v1
RequestImap(1742990618) -- Provisions Wagon v2
RequestImap(-751959361) -- Provisons Wagon v3
RequestImap(-492479795) -- Skull Provisions Wagon
RequestImap(-320577790) -- Barrel with Lantern
RequestImap(-850189983)  --Table - Cutting Board - Barrel of Salt v2
RequestImap(-1291679096) -- Potato Bags for Wagon v3
RequestImap(1309652195) -- Water and Dishes
RequestImap(-112364237) --Ammo Tools
RequestImap(1886481528) -- Spilled flour
RequestImap(-1507376753) -- Bag of Flour

-- Javiers Tent
RequestImap(-347518940) -- Skull near Banjo
RequestImap(-1887167048) -- Banjo
RequestImap(530288130) -- Cushion Top near log
RequestImap(1538837441) -- Fur seat for Log near Banjo
RequestImap(-1999825729) -- Brown Cow Hide near Banjo

-- Hosea
RequestImap(1674800958) -- Tent v2 Empty 660 -1256 43
RequestImap(1209017192) -- Tent v7 open front
RequestImap(-2001921071) -- Square Rug near round table top
RequestImap(1210820782) -- Barrel with Latntern

-- Bills Sleeping Area
RequestImap(-1292493167) -- Rope and Boxes near Dream Catcher
RequestImap(1128417383) -- v3 Canopy with Candle
RequestImap(292845400) -- Skull and bucket Near Rope and Boxes
RequestImap(-948006506) -- Blue Towel Dynamite
RequestImap(1700045179) -- Dynamite
RequestImap(-1045678888) -- Small Tables
RequestImap(-1663177928) --Lure Kit

--Back Wagons
RequestImap(1084869405) -- Two Wagons v1 Supplies 674 -1267 43
-- Dutchs tent
RequestImap(539843907) -- Tent v2 Empty Right Side Opened
RequestImap(1049842342) -- Inside Tent Bear Rug Stove Books Barrels and Canopy 
RequestImap(2119205605) -- Cash Box behind Dutchs Tent 1

-- Base
RequestImap(1802272784) -- Camp Extras (MUST LOAD FOR NORMAL SETUP)
RequestImap(2108368013) -- Tent frames for Dutch, Hosea and Arthurs Bed (Must Load for Normal Setup)
RequestImap(1706275010) -- Round Table
RequestImap(-792944828) -- Round Table Top
RequestImap(1290371072) -- Seats and light for round table
RequestImap(-2000080725) -- Chicken Coop
RequestImap(719147410) -- Blue Chair and Stool for gaming table
RequestImap(-989202374) -- Antlers on Big Center Tree
RequestImap(1717489303) -- Three Lean Tos
RequestImap(1692451176) -- Lantern Game Table on a Post
RequestImap(-1045282549) -- White Animal Skin Rugs near sitting rock
RequestImap(2123887232) -- Fire pit near white skins
RequestImap(-809371454) -- Small barrel and table to Banjo
RequestImap(-436009554) -- Piece of Paper near Banjo
RequestImap(1997423854) -- Map near Paper
RequestImap(157361403) -- Large Dream Catcher
RequestImap(-814821283) -- Fishing Stuff
------------------------------------- #### END OF RHODES STORY CAMP ####

------------------------------------- Rhodes Camp
--RequestImap(-159557995) -- Two Tents, Wagon, Chairs
------------------------------------- #### END OF RHODES CAMP ####

------------------------------------- Boat and Supplies Near Rhodes Camp
RequestImap(1733394134) -- Boat and Supplies 807 -1235 41
------------------------------------- #### END OF RHODES BOAT ####

------------------------------------- Rhodes Camp
RequestImap(1313890873) -- Small Camp in the Woods Just North of Dutch's Rhodes Base
------------------------------------- #### END OF RHODES CAMP ####

------------------------------------- Rhodes Cemetery
RequestImap(-1366431554) -- Covers Large hole with grass patch
RequestImap(-2144587490) -- Covers small plot hole with mound of dirt
------------------------------------- #### END OF RHODES CEMETERY ####

------------------------------------- Braithwaite Mansion
--Mansion Interior
RequestImap(1149195254)  --Brathwaite House Shell
RequestImap(58066174)  -- Interior
-- Mansion Exterior 
RequestImap(-1521525254)  --Green House Valentine -- Exterior Trees and Flowers 1(Run 1 and 2 together)
RequestImap(-761186147)  --Green House Valentine -- Exterior Trees and Flowers 2(Run 1 and 2 together)
RequestImap(-2137633069)  -- Shudders Close Upstairs Bedroom and Downstairs Library
RequestImap(-880373663)  -- Front Balcony Lantern Added
RequestImap(-70021332)  -- Adds Working tools and supplies to upper balcony
------------------------------------- #### END OF BRAITHWAITE MANSION ####

------------------------------------- Grey Estates
RequestImap(-677977650) -- Normal Barn Frame
RequestImap(702350293) -- Barn Interior
RequestImap(1426715569) -- Adds Field Props
RequestImap(26815048) -- Normal Fields
RequestImap(-1229109520) -- Green Plants
------------------------------------- #### END OF GREY ESTATES ####

------------------------------------- Black Water Town Hall
RequestImap(-2082201137)  --Blackwater Ground Town Hall
RequestImap(1343343014)  --Black Water Town Hall Addons Construction
RequestImap(739412171)  -- Two Boards in front of city hall (Goes with Town Hall Construction)
RequestImap(-5339556)  --Bank Under Construction
------------------------------------- #### END OF BLACKWATER TOWN HALL ####

------------------------------------- First Camp - Winter Area -1346 2407 311
RequestImap(-1331012521) -- Ground After Snowfall Winter 
RequestImap(-1991237877) -- Boxes
RequestImap(-1670453688) -- Broken Wagons
RequestImap(-743781837) -- Fire in Pit
RequestImap(2114706334) -- Fire Pit
RequestImap(-1306375743) -- Forge Fire
------------------------------------- #### END OF FIRST CAMP ####

------------------------------------- Farm House near Mining Town - -559 2686 319
RequestImap(-338553155) -- Exterior House
RequestImap(-1636879249) -- Normal Looking Interior
RequestImap(-1106668087) -- Adds Wagon Wheel near Front Door
RequestImap(2028590076) -- Cash Box Interior
------------------------------------- #### END OF FARM HOUSE ####

------------------------------------- Strawberry
RequestImap(131323483)  -- Doctors House Interior and Unlocked Front Door
RequestImap(270920361) -- Crates on Doctors Porch 

RequestImap(1892122519)-- Locked Door Micahs Gun House (No Interior) -1773 -431 154
RequestImap(-130638369) -- Micahs Gun House Interior with Unlocked Front Door (Upstairs does not work, other doors are locked)

RequestImap(2137790641) -- Jail Cell Window Fixed
RequestImap(1934919499) -- Jail Cell Window Fixed
RequestImap(-515396642) -- Jail Cell Window Fixed
------------------------------------- #### END OF STRAWBERRY ####

RequestImap(62512826)
RequestImap(1234648758)