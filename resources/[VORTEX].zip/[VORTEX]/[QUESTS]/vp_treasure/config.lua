Config = {}
Config.NoMoney = 'You do not have enough money'
Config.Shoptext = 'Aperte (E) comprar animal'
Config.LevelMissing = 'You are not a high enough level to own this pet'

Config.Coords = {
	vector3(-273.51,689.26,113.41)
}

Config.Spawndog = {
	vector4( -284.09, 685.34, 113.59, 234.45 )
}