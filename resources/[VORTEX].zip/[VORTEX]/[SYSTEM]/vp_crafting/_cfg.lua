Config = {
    ["fishingrod"] = {
        ["raw_gold"] = 2,
        ["ammo_pistol"] = 5
    },
    ["shotgun_pump"] = {
        ["raw_gold"] = 10,
        ["gold"] = 10
    },
    ["sulfur"] = {
        ["raw_gold"] = 5,
        ["gold"] = 2
    },
    ["pickaxe"] = {
        ["raw_gold"] = 5,
        ["gold"] = 2
    }
}
