CraftablePool = {
    {
        input = {
            -- ["string"] = 3,
            ["w_lasso"] = 1
        },
        output = {"w_shotgun_doublebarrel", 1}
    }
}

CraftableExclusivePool = {
    [1] = {
        input = {
            ['gunpowder'] = 1,
            ['wood'] = 2
        },
        output = {"w_shotgun_doublebarrel", 1},
    }
}
