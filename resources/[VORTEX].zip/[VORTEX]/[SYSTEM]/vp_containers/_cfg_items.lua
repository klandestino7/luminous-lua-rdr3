ItemPool = {
    ["w_shotgun_doublebarrel"] = {
        type = "weapon",
        name = "Shotgun de cano duplo",
        desc = "Descrição breve.",
        weight = 1.0,
        maxStackSize = 1
    },
    ["w_lasso"] = {
        type = "weapon_melee",
        name = "Shotgun de cano duplo",
        desc = "Descrição breve.",
        weight = 1.0,
        maxStackSize = 1
    },
    ["w_molotov"] = {
        type = "weapon_thrown",
        name = "Shotgun de cano duplo",
        desc = "Descrição breve.",
        weight = 1.0,
        maxStackSize = 1
    },
    ["a_shotgun"] = {
        type = "ammo",
        name = "Muniçao de Shotgun",
        desc = "Descrição breve.",
        weight = 1.0,
        maxStackSize = 60
    },
    ["dollar"] = {
        type = "valuable",
        name = "Dollar",
        desc = "Descrição breve.",
        weight = 1.0,
        maxStackSize = 1
    }
}
