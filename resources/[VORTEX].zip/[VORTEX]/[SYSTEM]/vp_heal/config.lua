Config = {}

Config.NoMoney = 'Não tem dinheiro suficiente $'
Config.Shoptext = 'Aperte (E) para se curar'
Config.Coords = {
	Codds = {
		vector3(-285.87, 805.07, 119.39),
	},
	Locations = {
		vector3(-285.87, 805.07, 119.39),
	}
}