Config = {}

Config.xpuser = 20 -- XP