local Tunnel = module("_core", "lib/Tunnel")
local Proxy = module("_core", "lib/Proxy")

cAPI = Proxy.getInterface("API")
API = Tunnel.getInterface("API")

local horseModel
local horseName
local horseComponents = {}

-- ! REMOVE
-- horseModel = "A_C_Horse_Turkoman_Gold"
-- horseName = "Burrinho"
-- ! REMOVE

local prompt_inventory
local prompt_eat
local prompt_brush
local prompt_drink

-- AUDIO::PLAY_SOUND_FRONTEND("Core_Fill_Up", "Consumption_Sounds", true, 0);

function NativeSetPlayerHorse(horseEntity)
    Citizen.InvokeNative(0xD2CB0FB0FDCB473D, PlayerId(), horseEntity)
end

function SetPlayerHorse(horseEntity)
    playerHorse = horseEntity
end

function NativeSetPedComponentEnabled(ped, component)
    Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, component, true, true, true)
end

function SetHorseInfo(horse_model, horse_name, horse_components)
    horseModel = horse_model
    horseName = horse_name
    horseComponents = horse_components
end

RegisterNetEvent("VP:HORSE:SetHorseInfo")
AddEventHandler("VP:HORSE:SetHorseInfo", SetHorseInfo)

function InitiateHorse(atCoords)
    cAPI.DestroyPlayerHorse()
    print(horseModel, horseName)
    local ped = PlayerPedId()
    local pCoords = GetEntityCoords(ped)

    local modelHash = GetHashKey(horseModel)

    if not HasModelLoaded(modelHash) then
        RequestModel(modelHash)
        while not HasModelLoaded(modelHash) do
            Citizen.Wait(10)
        end
    end

    local spawnPosition

    if atCoords == nil then
        local x, y, z = table.unpack(pCoords)
        local bool, nodePosition = GetClosestVehicleNode(x, y, z, 1, 3.0, 0.0)

        local index = 0
        while index <= 25 do
            local _bool, _nodePosition = GetNthClosestVehicleNode(x, y, z, index, 1, 3.0, 2.5)
            if _bool == true or _bool == 1 then
                bool = _bool
                nodePosition = _nodePosition
                index = index + 3
            else
                break
            end
        end

        spawnPosition = nodePosition
    else
        spawnPosition = atCoords
    end

    local entity = CreatePed(modelHash, spawnPosition, GetEntityHeading(ped), true, true)
    -- -- SetModelAsNoLongerNeeded(modelHash)

    Citizen.InvokeNative(0x283978A15512B2FE, entity, true)

    cAPI.SetPlayerHorse(entity)

    if horseModel == GetHashKey("A_C_HORSE_MORGAN_FLAXENCHESTNUT") then
        NativeSetPedComponentEnabled(entity, 0x106961A8) --sela
        NativeSetPedComponentEnabled(entity, 0x508B80B9) --blanket
    end

    Citizen.InvokeNative(0x283978A15512B2FE, entity, true)

    -- SetVehicleHasBeenOwnedByPlayer(playerHorse, true)
    SetPedNameDebug(entity, horseModel)
    SetPedPromptName(entity, horseName)

    if prompt_inventory == nil then
        InitiatePrompts()
    end

    local prompt_group = PromptGetGroupIdForTargetEntity(entity)

    PromptSetGroup(prompt_inventory, prompt_group)
    PromptSetGroup(prompt_eat, prompt_group)
    PromptSetGroup(prompt_brush, prompt_group)
    PromptSetGroup(prompt_drink, prompt_group)

    if horseComponents ~= nil then
        for _, componentHash in pairs(horseComponents) do
            NativeSetPedComponentEnabled(entity, tonumber(componentHash))
        end
    end

    TaskGoToEntity(entity, ped, -1, 7.2, 2.0, 0, 0)

    SetPedConfigFlag(entity, 297, true) -- Enable_Horse_Leadin

    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedValue", 8)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedMinValue", false)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedMaxValue", 10);
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedEquipmentValue", bVar2)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedEquipmentMinValue", false)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedEquipmentMaxValue", 10)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedCapacityValue", bVar3)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedCapacityMinValue", false)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseSpeedCapacityMaxValue", 10)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccValue", bVar4)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccMinValue", false)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccMaxValue", 10)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccEquipmentValue", bVar5)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccEquipmentMinValue", false)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccEquipmentMaxValue", 10)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccCapacityValue", bVar6)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccCapacityMinValue", false)
    -- Citizen.InvokeNative(0x307A3247C5457BDE, horseEntity, "HorseAccCapacityMaxValue", 10)

    -- Citizen.InvokeNative(0x8538F1205D60ECA6, horseEntity, "HorseHandling", GetHashKey('HORSE_HANDLING_RACE'))
    -- Citizen.InvokeNative(0x8538F1205D60ECA6, horseEntity, "HorseType", GetHashKey('HORSE_CLASS_RACE'))
    -- Citizen.InvokeNative(0x8538F1205D60ECA6, horseEntity, "HorseBreed", GetHashKey(fufrp_1359(iVar1)));
    -- Citizen.InvokeNative(0x8538F1205D60ECA6, horseEntity, "HorseCoat", GetHashKey('COAT_CHOCR'))
    -- Citizen.InvokeNative(0x8538F1205D60ECA6, horseEntity, "HorseGender", GetHashKey('HORSE_GENDER_FEMALE'))
end

function SetHorseComponentEnabled(hash)
    local model2 = GetHashKey(tonumber(hash))
    if not HasModelLoaded(model2) then
        Citizen.InvokeNative(0xFA28FE3A6246FC30, model2)
    end
    Citizen.InvokeNative(0xD3A7B003ED343FD9, horseEntity, tonumber(hash), true, true, true)
end

function drawBoundingBox()
    if cAPI.IsPlayerHorseActive() then
        local playerHorse = cAPI.GetPlayerHorse()
        local min, max = GetModelDimensions(GetEntityModel(playerHorse))

        local horseCoords = GetEntityCoords(playerHorse)

        local z = min.z

        -- front = vec3(front.xy, z)
        -- local back =
        local A = GetOffsetFromEntityInWorldCoords(playerHorse, vec3(min.x, max.y, z))
        local B = GetOffsetFromEntityInWorldCoords(playerHorse, vec3(max.x, max.y, z))
        local C = GetOffsetFromEntityInWorldCoords(playerHorse, min)
        local D = GetOffsetFromEntityInWorldCoords(playerHorse, vec3(max.x, min.y, z))

        local coords = horseCoords - vec3(0, 0, 1.0)

        -- DrawLine(coords, front, 0, 255, 0, 255)
        DrawLine(coords, A, 255, 255, 255, 255)
        DrawLine(coords, B, 255, 255, 255, 255)
        DrawLine(coords, C, 255, 255, 255, 255)
        DrawLine(coords, D, 255, 255, 255, 255)

        -- raycastDrinkable()
        raycastEatable()
    end
end

function raycastDrinkable()
    local playerHorse = cAPI.GetPlayerHorse()
    local boneIndex = GetEntityBoneIndexByName(playerHorse, "skel_head")
    local bonePosition = GetWorldPositionOfEntityBone(playerHorse, boneIndex)
    local groundCoords = vec3(bonePosition.xy, A.z)
    local waterPosition = vec3(table.unpack(exports["vp_horse"]:js_native(bonePosition.x, bonePosition.y, bonePosition.z, groundCoords.x, groundCoords.y, groundCoords.z)))
    if waterPosition.x ~= 127 and waterPosition.y ~= 0 and waterPosition.z ~= 0 then
        DrawLine(bonePosition, waterPosition, 0, 0, 255, 255)
    else
        DrawLine(bonePosition, groundCoords, 255, 0, 0, 255)
    end
    DrawLine(coords, bonePosition, 255, 255, 0, 255)
end

function raycastEatable()
    local playerHorse = cAPI.GetPlayerHorse()
    local min, max = GetModelDimensions(GetEntityModel(playerHorse))

    local horseCoords = GetEntityCoords(playerHorse)

    local z = min.z

    local A = GetOffsetFromEntityInWorldCoords(playerHorse, vec3(min.x, max.y, z))

    local boneIndex = GetEntityBoneIndexByName(playerHorse, "skel_head")
    local bonePosition = GetWorldPositionOfEntityBone(playerHorse, boneIndex)

    local groundCoords = vec3(bonePosition.xy, A.z)

    local shapeTestRay = StartShapeTestRay(bonePosition, groundCoords, 256, playerHorse, 0)

    local retVal, hit, endCoords, surfaceNormal, entityHit = GetShapeTestResult(shapeTestRay)

    if hit ~= 0 then
        DrawLine(bonePosition, endCoords, 255, 255, 0, 255)
    end
end

-- function setHorseComponents(components)
--     horseComponents = components
--     for _, componentHash in pairs(horseComponents) do
--         Citizen.InvokeNative(0xD3A7B003ED343FD9, horseEntity, componentHash, true, true, true)
--     end
-- end


AddEventHandler('VP:EVENTS:PedWhistle', function(ped, whistleType)
    if ped == PlayerPedId() then
        WhistleHorse()
    end
end)

function WhistleHorse()
    if cAPI.IsPlayerHorseActive() and not cAPI.IsPlayerHorseActivationBlocked() then
        local playerHorse = cAPI.GetPlayerHorse()
        if GetScriptTaskStatus(playerHorse, 0x4924437D, 0) ~= 0 then
            TaskGoToEntity(playerHorse, PlayerPedId(), -1, 7.2, 2.0, 0, 0)
        else
            -- cAPI.notify("error", "Seu cavalo já está vindo")
        end
    else
        if not cAPI.IsPlayerHorseActivationBlocked() then
            -- InitiateHorse()
            InitiateHorse(GetOffsetFromEntityInWorldCoords(PlayerPedId(), 1.0, 1.0, 0.0))
        else
            cAPI.notify("error", "Seu cavalo está ferido, aguarde " .. horseActivationSeconds .. " segundos")
        end
    end
end

function InitiatePrompts()
    prompt_inventory = PromptRegisterBegin()
    PromptSetControlAction(prompt_inventory, 0x5966D52A)
    PromptSetText(prompt_inventory, CreateVarString(10, "LITERAL_STRING", "Abrir Aforje"))
    PromptSetEnabled(prompt_inventory, 1)
    PromptSetVisible(prompt_inventory, 1)
    PromptSetStandardMode(prompt_inventory, 1)
    -- Citizen.InvokeNative(0x0C718001B77CA468, prompt_inventory, 1.5)
    PromptRegisterEnd(prompt_inventory)

    prompt_eat = PromptRegisterBegin()
    PromptSetControlAction(prompt_eat, 0xB4E465B4)
    PromptSetText(prompt_eat, CreateVarString(10, "LITERAL_STRING", "Mandar Pastar"))
    PromptSetEnabled(prompt_eat, 1)
    PromptSetVisible(prompt_eat, 0)
    PromptSetStandardMode(prompt_eat, 1)
    -- Citizen.InvokeNative(0x0C718001B77CA468, prompt_eat, 1.5)
    PromptRegisterEnd(prompt_eat)

    prompt_drink = PromptRegisterBegin()
    PromptSetControlAction(prompt_drink, 0x24978A28)
    PromptSetText(prompt_drink, CreateVarString(10, "LITERAL_STRING", "Mandar Beber"))
    PromptSetEnabled(prompt_drink, 1)
    PromptSetVisible(prompt_drink, 0)
    PromptSetStandardMode(prompt_drink, 1)
    -- Citizen.InvokeNative(0x0C718001B77CA468, prompt_drink, 1.5)
    PromptRegisterEnd(prompt_drink)

    prompt_brush = PromptRegisterBegin()
    PromptSetControlAction(prompt_brush, 0x9959A6F0)
    PromptSetText(prompt_brush, CreateVarString(10, "LITERAL_STRING", "Escovar"))
    PromptSetEnabled(prompt_brush, 1)
    PromptSetVisible(prompt_brush, 1)
    PromptSetStandardMode(prompt_brush, 1)
    -- Citizen.InvokeNative(0x0C718001B77CA468, prompt_brush, 1.5)
    PromptRegisterEnd(prompt_brush)
end

Citizen.CreateThread(
    function()
        -- print(GetHashKey("BASE"))
        -- print(GetHashKey("CUSTOM"))
        -- print(GetHashKey("COMPONENT"))

        while true do
            Citizen.Wait(0)

            if PromptIsJustPressed(prompt_inventory) then
                TriggerServerEvent("VP:HORSE:OpenInventory")
            end

            -- if PromptIsJustPressed(prompt_eat) then
            --     TaskAnimalInteraction(PlayerPedId(), cAPI.GetPlayerHorse(), GetHashKey("INTERACTION_FOOD"), GetHashKey("s_horsnack_carrot01x"), 1)
            -- end

            -- if PromptIsJustPressed(prompt_brush) then
            --     TaskAnimalInteraction(PlayerPedId(), cAPI.GetPlayerHorse(), GetHashKey("INTERACTION_BRUSH"), GetHashKey("p_brushhorse01x"), 1)
            -- end

            -- print(IsPlayerTargettingAnything(PlayerId()))

            if CanHorseEat() then
                PromptSetVisible(prompt_eat, true)
                if PromptIsJustPressed(prompt_eat) then
                    HandleEat()
                end
            else
                PromptSetVisible(prompt_eat, false)
            end

            if CanHorseDrink() then
                PromptSetVisible(prompt_drink, true)
                if PromptIsJustPressed(prompt_drink) then
                    HandleDrink()
                end
            else
                PromptSetVisible(prompt_drink, false)
            end

            -- if IsControlPressed(0, 0xF8982F00) then
            --     local mount = GetMount(PlayerPedId())
            --     print(mount, cAPI.GetPlayerHorse())
            --     if mount ~= 0 and mount == cAPI.GetPlayerHorse() then
            --         PromptSetActiveGroupThisFrame(PromptGetGroupIdForTargetEntity(mount), CreateVarString(10, 'LITERAL_STRING', "horseName"))
            --     end
            -- end

            if IsControlJustPressed(0, 0xE7EB9185) or IsControlJustPressed(1, 0x24978A28) then -- H, HistleHorseBack - H, Histle
                -- if GetScriptTaskStatus(PlayerPedId(), 0x1DE2A7BD, 0) ~= 1 then
                --     local mount = GetMount(PlayerPedId())

                --     if CanHorseDrink() then
                --         HandleDrink()
                --     elseif CanHorseEat() then
                --         HandleEat()
                --     else
                -- if IsControlJustPressed(0, 0x24978A28) then -- H, Histle
                    WhistleHorse()
                -- -- end
            --     end
            -- end
            end

            if IsControlJustPressed(0, 0x7D5B3717) then --and IsControlJustPressed(0, 0xE4D2CE1D) then
                local mount = GetMount(PlayerPedId())
                if mount ~= 0 then
                    -- TaskHorseActionmount, 2, 0, 0) -- dropar
                    TaskHorseAction(mount, 5, 0, 0) -- empinar
                -- TaskHorseAction(mount, 3, 0, 0) -- freiar
                end
            end

            if IsControlJustPressed(0, 0xE16B9AAD) then
                local mount = GetMount(PlayerPedId())
                if mount ~= 0 then
                    TaskHorseAction(mount, 3, 0, 0) -- Freiada brusca
                end
            end

            -- drawBoundingBox()
        end
    end
)

AddEventHandler(
    "onResourceStop",
    function(resourceName)
        if GetCurrentResourceName() == resourceName or resourceName == "_core" then
            cAPI.DestroyPlayerHorse()
        end
    end
)
