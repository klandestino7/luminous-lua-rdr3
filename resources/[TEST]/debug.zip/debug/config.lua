Config	= {}
Config.DrawCoords = GetConvarInt("spanser_drawcoords", 1)
Config.TrackEntities = GetConvarInt("spanser_trackentities", 0)
Config.TrackFoliage = GetConvarInt("spanser_trackfoliage", 0)
Config.TrackItems = GetConvarInt("spanser_trackitems", 0)
Config.TrackVehicles = GetConvarInt("spanser_trackvehicles", 0)
