local blips = {
	-- x, y, z, type, name
	{},
}
