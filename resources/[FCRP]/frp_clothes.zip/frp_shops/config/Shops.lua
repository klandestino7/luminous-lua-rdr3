Config = {}

Config.Shops = {
    {
        shopSprite = 1475879922,
        shopName = "Loja de Utensílios",
        position = {
            x = 1420.377,
            y = 379.588,
            z = 90.32043,
        },
        items = {
            {
                itemId = "",
                itemName = "Tenda Pequena",
                level = 1,
                money = 100,
                gold = 2
            },
        }
    },
}