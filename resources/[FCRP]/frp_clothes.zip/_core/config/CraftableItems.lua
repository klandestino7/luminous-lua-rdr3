CraftableItems = {
    ['weapon_fishingrod'] = {
        craftingDesc = "LOREM IPSUR",
        craftingParts = {
            ['generic_corda'] = 2,
            ['generic_provision_rf_wood_stick'] = 5,
        }
    },
    ['weapon_shotgun_pump'] = {
        craftingDesc = "LOREM IPSUR",
        craftingParts = {
            ['generic_metalbruto'] = 10,
            ['generic_provision_coal'] = 10,
        }
    },
    ['kit_camp_simple'] = {
        craftingDesc = "LOREM IPSUR",
        craftingParts = {
            ['generic_pedra'] = 5,
            ['generic_provision_rf_wood_minor'] = 2,
        }
    },

    ['kit_camp_simple'] = {
        craftingDesc = "LOREM IPSUR",
        craftingParts = {
            ['generic_pedra'] = 5,
            ['generic_provision_rf_wood_minor'] = 2,
        }
    },

}