Clothes = {
    ["chapeu"] = {
        name = "chapeu",
        hash = 0x9925C067
    },
    ["camisa"] = {
        name = "camisa",
        hash = 0x2026C46D
    },
    ["colete"] = {
        name = "colete",
        hash = 0x485EE834
    },
    ["casaco"] = {
        name = "casaco",
        hash = 0x662AC34
    },
    ["calca"] = {
        name = "calca",
        hash = 0x1D4C528A
    },
    ["mascara"] = {
        name = "mascara",
        hash = 0x7505EF42
    },
    ["botas"] = {
        name = "botas",
        hash =0x777EC6EF
    },
    ["luvas"] = {
        name = "luvas",
        hash = 0xEABE0032
    },
    ["saia"] = {
        name = "saia",
        hash = 0xA0E3AB7F
    },
    ["coldre"] = {
        name = "coldre",
        hash = 0x9B2C8B89
    }
}