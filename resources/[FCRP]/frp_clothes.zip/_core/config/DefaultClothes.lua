DefaultClothes = {
    ["mp_male"] = {
        casaco = 0x1B164391,
        camisa = 0x10B87936,
        botas = 0x11B7CAB1,
        calca = 0x1526EAB7
    },
    ["mp_female"] = {
        casaco = 0x15B760CE,
        camisa = 0x1178F4F4,
        botas = 0x141281DC,
        calca = 0x1945CE44
    }
}