ConfigStaticChests = {
    -- {
    --     x,
    --     y,
    --     z,
    --     h,
    --     type, -- GLOBAL[0] | PUBLIC[1] | PRIVATE[2]
    --     capacity, 
    --     group,
    -- },
    {
        -3145.66,
        1091.81,
        20.69,
        180.00,
        0,
        20,
        'admin',
    }
}