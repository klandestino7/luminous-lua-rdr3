Chests = {
    -- x, y, z, capacity, type(0/1/2)
    {0, 0, 0, 20, 0},
    {0, 0, 0, 20, 0},
}
