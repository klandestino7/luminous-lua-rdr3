Config = {}

Config.NoMoney = 'Não tem dinheiro suficiente $'
Config.Shoptext = 'Aperte (E) para abrir o menu'
Config.Coords = {
	vector3(-3622.86, -2605.45, 13.34),  --ARMADILLO
	vector3(-5527.6, -2953.36, -0.7), -- TUMBLEWEED
	vector3(-759.17, -1266.61, 44.06),  -- BLACKWATER
	vector3(-1808.51, -348.13, 164.65), -- STRAWBERRY
	vector3(-275.95, 804.97, 119.38), -- VALENTINE
	vector3(2512.04,-1308.5, 48.95) -- SAINT DENIS
}

Config.DVCoords = {
	--vector3(-3622.86, -2605.45, 13.34),  --ARMADILLO
	--vector3(-5527.6, -2953.36, -0.7), -- TUMBLEWEED
	--vector3(-759.17, -1266.61, 44.06),  -- BLACKWATER
	vector3(-1802.35, -346.11, 164.35), -- STRAWBERRY
	vector3(-267.51, 802.45, 119.05), -- VALENTINE
	vector3(2490.16, -1321.22, 48.87) -- SAINT DENIS
}

Config.SPAWNCoords = {
	--vector3(-3622.86, -2605.45, 13.34),  --ARMADILLO
	--vector3(-5527.6, -2953.36, -0.7), -- TUMBLEWEED
	--vector3(-759.17, -1266.61, 44.06),  -- BLACKWATER
	vector3(-1802.35, -346.11, 164.35),-- STRAWBERRY
	vector3(-267.51, 802.45, 119.05) -- VALENTINE
}
