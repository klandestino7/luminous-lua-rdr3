local Tunnel = module('_core', 'libs/Tunnel')
local Proxy = module('_core', 'libs/Proxy')

API = Proxy.getInterface('API')
cAPI = Tunnel.getInterface('API')


RegisterNetEvent('ROUBO:sheriffs_call')
AddEventHandler('ROUBO:sheriffs_call', function(amount)
          
end)