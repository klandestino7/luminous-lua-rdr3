Config = {}

Config.NoMoney = 'Não tem dinheiro suficiente $'
Config.Shoptext = 'Aperte (E) para alugar uma carroça'
Config.LevelMissing = 'Você não tem experiência suficiente' 
Config.Coords = {
	vector3(-396.05, 655.52, 114.57), -- valentine
	vector3(1889.65, -1343.7, 42.51), -- saint denis
    vector3(-5514.86, -3044.4, -2.39),
}