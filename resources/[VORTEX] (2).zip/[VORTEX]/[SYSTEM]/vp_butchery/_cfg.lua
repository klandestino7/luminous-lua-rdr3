Config = {}

Config.Coords = {
	vector3(-1753.07, -394.78, 156.18),   --Cabana de Açougue de Strawberry
	vector3(-341.08, 767.16, 116.71),    --Cabana de Açougue de Valentine
	vector3(1296.28, -1279.22, 75.84),  --Cabana de Açougue de Rhodes
	vector3(-5508.29, -2948.16, -1.87)   --Cabana de Açougue de Tumbleweed
}
 

Config.PedAcougue = {
{x = -339.21, y = 767.67, z = 116.57, h = 93.03}, -- VALENTINE
}

Config.Acougue = {

{ x= -341.10, y = 767.28, z = 116.71 }, --val
{ x = -754.77, y = -1287.01, z = 43.63 },  --blackwater
{ x = 1296.56, y = -1279.44, z = 75.84 },  --rhodes
{ x = -1752.91, y = -394.74, z = 156.19 },  --strawberry
{ x = -5508.09, y = -2947.91, z = -1.87 },  --tumbleweed
{ x = 2817.59, y = -1329.61, z = 46.52 },  --saintdenis

}