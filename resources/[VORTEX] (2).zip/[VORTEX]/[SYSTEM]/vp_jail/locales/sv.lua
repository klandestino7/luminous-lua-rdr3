Locales ['sv'] = {
	['blip_name']          = 'fängelse',
	['judge']              = 'fängelse',
	['escape_attempt']     = 'du får inte rymma från fängelset!',
	['remaining_msg']      = 'det kvarstår ~b~%s~s~ sekunder tills du släpps från fängelset',
	['jailed_msg']         = '%s sitter i fängelse i %s minuter!',
	['unjailed']           = '%s har blivit befriad från fängelset!'
}
