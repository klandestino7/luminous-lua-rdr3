## redemrp_notification 0.8v

## 2. Installation

Add ```ensure redemrp_notification``` in server.cfg

## 3. How to start
You can use:

```TriggerEvent("redemrp_notification:start", "Simple test redemrp_notification" , 5)```

OR

```local timer = 5```

```local text = "Simple test redemrp_notification"```

```TriggerEvent("redemrp_notification:start", text, timer)```


You can unlock test command in client.lua

## 4. Credits
[Ktos93](http://github.com/amakuu)

Join discord to get support! - https://discord.gg/FKH4uwb
